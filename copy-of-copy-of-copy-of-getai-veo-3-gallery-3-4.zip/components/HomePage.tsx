/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React from 'react';

/**
 * A component that renders the hero content for the home page.
 * It acts as an overlay on top of the blurred project gallery.
 */
export const HomePage: React.FC = () => {
  return (
    <div className="home-hero-content animate-fade-in">
      <h1 className="home-hero-title">
        БЫСТРО - ЭТО МЕДЛЕННО,
        <br />
        НО ПОСТОЯННО
      </h1>
      <div className="home-brand-container">
        <h2 className="home-brand-title">GETAI</h2>
        <p className="home-hero-subtitle">AI Content Studio</p>
      </div>
      <p className="home-signature">get a</p>
    </div>
  );
};
